import serve from '..'
export function getTableData () {
  return serve({
    method: 'GET',
    url: '/home/tabledata'
  })
}
