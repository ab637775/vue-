import axios from 'axios'
const serve = axios.create({
  baseURL: 'https://www.fastmock.site/mock/22445b5baad4174802cf9a16b3f01825/api',
  timeout: 10000
})
export default serve
